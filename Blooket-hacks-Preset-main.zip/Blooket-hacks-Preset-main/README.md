# Blooket-hacks-Preset
Made for Minesraft2 and now passed on to 05Konz's blooket hacks I will try to add constantly also pls star is you like the hack and preset

# How do i Use this?
When you have Minesraft2's blooket hack (click this link if you want the hacks for chrome --> https://github.com/05Konz/Blooket-Cheats/blob/main/tutorial/GoogleChrome.md  for microsoftedge --> https://github.com/05Konz/Blooket-Cheats/blob/main/tutorial/MicrosoftEdge.md Opera GX --> https://github.com/05Konz/Blooket-Cheats/blob/main/tutorial/OperaGX.md(here's for the bookmarklet--> https://github.com/05Konz/Blooket-Cheats/blob/main/cheats/Bookmarklets.html ) ) go to settings > Import setting it should say JSON data > and past the code Tada now you have blooket hacks(if you already) and a cool preset
